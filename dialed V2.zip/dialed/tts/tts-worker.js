/* On-device voice for the DJ. Runs the open Kokoro-82M speech model
   (Apache-2.0) in a Web Worker so the music and crossfades never stutter
   while he is "talking". Weights (~90 MB) download once from Hugging Face
   and are kept in the browser's cache; nothing you type leaves your computer. */
import { KokoroTTS, env } from './kokoro.web.js';

env.wasmPaths = new URL('./ort/', import.meta.url).href;   // WebAssembly runtime shipped next to this file
const MODEL = 'onnx-community/Kokoro-82M-v1.0-ONNX';

const VOICE_BASE = 'https://huggingface.co/' + MODEL + '/resolve/main/voices/';
/* Blended voices. The engine only accepts its own voice names, so each blend is written into the voice
   cache under the name of a voice we don't offer (the engine reads that cache before downloading). */
const BLENDS = {
  mix_deep:   { slot: 'am_santa', parts: { am_onyx: 0.6, am_fenrir: 0.4 } },
  mix_velvet: { slot: 'af_river', parts: { am_onyx: 0.5, am_michael: 0.5 } },
};
const blended = {};

async function voiceBytes(name, cache) {
  const url = VOICE_BASE + name + '.bin';
  let r = await cache.match(url);
  if (!r) {
    r = await fetch(url);
    if (!r.ok) throw new Error('voice ' + name + ' unavailable (' + r.status + ')');
    try { await cache.put(url, r.clone()); } catch (e) { /* cache full or blocked: carry on */ }
  }
  return new Float32Array(await r.arrayBuffer());
}
async function resolveVoice(v) {
  const spec = BLENDS[v];
  if (!spec) return v;
  if (blended[v]) return spec.slot;
  const cache = await caches.open('kokoro-voices');
  const names = Object.keys(spec.parts), arrs = [];
  for (const n of names) arrs.push(await voiceBytes(n, cache));
  const out = new Float32Array(arrs[0].length); let total = 0;
  names.forEach((n, i) => { const w = spec.parts[n]; total += w; for (let k = 0; k < out.length; k++) out[k] += arrs[i][k] * w; });
  for (let k = 0; k < out.length; k++) out[k] /= total;
  await cache.put(VOICE_BASE + spec.slot + '.bin', new Response(out.buffer, { headers: { 'content-type': 'application/octet-stream' } }));
  blended[v] = true;
  return spec.slot;
}

let tts = null, loading = null, queue = Promise.resolve();
const post = (msg, transfer) => self.postMessage(msg, transfer || []);
const errText = e => String((e && e.message) || e || 'unknown error').slice(0, 300);

function load() {
  if (tts) return Promise.resolve(tts);
  if (!loading) {
    const files = {};
    loading = KokoroTTS.from_pretrained(MODEL, {
      dtype: 'q8', device: 'wasm',
      progress_callback: p => {
        if (!p || p.status !== 'progress' || !p.file) return;
        files[p.file] = { l: p.loaded || 0, t: p.total || 0 };
        let l = 0, t = 0;
        for (const k in files) { l += files[k].l; t += files[k].t; }
        post({ type: 'progress', pct: t ? Math.min(99, Math.round((l / t) * 100)) : 0, loaded: l, total: t });
      },
    }).then(m => (tts = m), e => { loading = null; throw e; });
  }
  return loading;
}

async function speak({ id, text, voice, speed }) {
  try {
    const m = await load();
    let v;
    try { v = await resolveVoice(voice); }
    catch (e) { v = BLENDS[voice] ? Object.keys(BLENDS[voice].parts)[0] : voice; }   // blend unavailable: use its main voice
    const a = await m.generate(text, { voice: v, speed });
    const data = new Float32Array(a.audio);          // own copy so the buffer can be transferred
    post({ type: 'audio', id, data, rate: a.sampling_rate }, [data.buffer]);
  } catch (e) {
    post({ type: 'audio-error', id, message: errText(e) });
  }
}

self.onmessage = ev => {
  const m = ev.data || {};
  if (m.type === 'init') load().then(() => post({ type: 'ready' }), e => post({ type: 'error', message: errText(e) }));
  else if (m.type === 'speak') queue = queue.then(() => speak(m));   // one line at a time
};
