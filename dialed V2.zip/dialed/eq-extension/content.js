/* Dialed EQ bridge
 *
 * Runs inside the YouTube player iframes that a Dialed page embeds.
 * It routes the player's <video> through a 10-band equalizer (Web Audio)
 * and takes its settings from the parent page over postMessage.
 *
 * It only activates when the embedding page is on localhost / 127.0.0.1,
 * and it does not touch the audio until the equalizer is switched on.
 */
(() => {
  'use strict';
  if (window.top === window) return;                        // only inside an embedded frame

  let parentOrigin = '';
  try { parentOrigin = (location.ancestorOrigins && location.ancestorOrigins[0]) || ''; } catch (e) { /* ignore */ }
  let host = '';
  try { host = new URL(parentOrigin).hostname; } catch (e) { /* ignore */ }
  if (host !== 'localhost' && host !== '127.0.0.1') return; // only talk to a local Dialed page

  const FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const st = { on: false, pre: 0, bands: new Array(10).fill(0) };
  let ctx = null, preamp = null, filters = [], analyser = null, hooked = null;
  let busy = false, poll = 0, sp = 0, lastStatus = '';

  const post = o => {
    try { window.parent.postMessage(JSON.stringify(Object.assign({ dialed: 1 }, o)), parentOrigin); } catch (e) { /* ignore */ }
  };
  const status = (ok, reason) => {
    const key = ok + '|' + (reason || '');
    if (key === lastStatus) return;
    lastStatus = key;
    post({ type: 'status', hooked: ok, reason: reason || '' });
  };

  function apply() {
    if (!ctx || !preamp) return;
    const t = ctx.currentTime;
    preamp.gain.setTargetAtTime(st.on ? Math.pow(10, st.pre / 20) : 1, t, 0.02);
    filters.forEach((f, i) => f.gain.setTargetAtTime(st.on ? st.bands[i] : 0, t, 0.02));
  }

  async function hook(video) {
    if (hooked === video) return true;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'playback' });
      if (ctx.state !== 'running') {
        await Promise.race([ctx.resume().catch(() => {}), new Promise(r => setTimeout(r, 800))]);
      }
      if (ctx.state !== 'running') { status(false, 'suspended'); return false; }

      // Build the whole chain first and touch the <video> last,
      // so a failure part-way can never leave the player silent.
      preamp = ctx.createGain();
      filters = FREQS.map((f, i) => {
        const b = ctx.createBiquadFilter();
        b.type = i === 0 ? 'lowshelf' : i === FREQS.length - 1 ? 'highshelf' : 'peaking';
        b.frequency.value = f; b.Q.value = 1.1; b.gain.value = 0;
        return b;
      });
      analyser = ctx.createAnalyser(); analyser.fftSize = 1024; analyser.smoothingTimeConstant = 0.7;
      let node = preamp;
      for (const f of filters) { node.connect(f); node = f; }
      node.connect(analyser); analyser.connect(ctx.destination);

      const src = ctx.createMediaElementSource(video);
      src.connect(preamp);
      hooked = video;
      apply();
      status(true);
      return true;
    } catch (e) {
      status(false, String((e && e.message) || e));
      return false;
    }
  }

  function ensure() {
    if (!st.on || busy) return;
    const v = document.querySelector('video');
    if (v && v !== hooked) { busy = true; hook(v).then(() => { busy = false; }, () => { busy = false; }); }
  }

  // log-spaced groups so the spectrum looks like music, not like a ramp
  const EDGES = (() => {
    const e = [1];
    for (let i = 1; i <= 32; i++) e.push(Math.max(e[i - 1] + 1, Math.round(Math.pow(511, i / 32))));
    return e;
  })();
  function sendSpectrum() {
    if (!analyser || !hooked || hooked.paused) return;
    const a = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(a);
    const bins = [];
    for (let i = 0; i < 32; i++) {
      const lo = EDGES[i], hi = Math.min(a.length, EDGES[i + 1]);
      let s = 0; for (let j = lo; j < hi; j++) s += a[j];
      bins.push(Math.round(s / Math.max(1, hi - lo)));
    }
    post({ type: 'spectrum', bins });
  }
  function setSpectrum(on) {
    if (on && !sp) sp = setInterval(sendSpectrum, 60);
    else if (!on && sp) { clearInterval(sp); sp = 0; }
  }

  window.addEventListener('message', e => {
    if (e.source !== window.parent || e.origin !== parentOrigin) return;
    let m = e.data;
    if (typeof m === 'string') { try { m = JSON.parse(m); } catch (err) { return; } }
    if (!m || m.dialed !== 1) return;
    if (m.type === 'hello') { post({ type: 'ready' }); return; }
    if (m.type === 'eq') {
      st.on = !!m.on;
      st.pre = clamp(+m.pre || 0, -12, 12);
      if (Array.isArray(m.bands)) st.bands = m.bands.slice(0, 10).map(x => clamp(+x || 0, -12, 12));
      while (st.bands.length < 10) st.bands.push(0);
      setSpectrum(!!m.spectrum);
      if (st.on) { ensure(); if (!poll) poll = setInterval(ensure, 1000); }
      apply();
    }
  });

  post({ type: 'ready' });
})();
